package com.example.workouttimer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Chronometer chronometer;
    boolean Running;
    long pauseTime;
    TextView workoutsummary;
    EditText workoutType;
    SharedPreferences sharedPreferences;



    String PREV_SUMMARY = "PREV_SUMMARY";
    String Summary = "Summary";
    String Pause = "Pause";
    String Base = "Base";
    String Timer_time = "TimerTime";





    public void onClick(View view){
        switch(view.getId()){
            case R.id.imageViewPlay:
                if(!Running){
                    chronometer.setBase(SystemClock.elapsedRealtime()-pauseTime);
                    chronometer.start();
                    Running=true;
                }
                break;

            case R.id.imageViewPause:
                if(Running){
                    chronometer.stop();
                    pauseTime=SystemClock.elapsedRealtime() - chronometer.getBase();
                    Running=false;
                }
                break;

            case R.id.imageViewStop:
                CharSequence time = chronometer.getText();
                if(workoutType.getText().toString().equals("")){
                    workoutsummary.setText("You have spent " + time.toString() +" on your workout last time");
                }
                else{
                    workoutsummary.setText("You have spent " + time.toString() +" on " + workoutType.getText().toString() + " Last time");
                }
                chronometer.stop();
                chronometer.setBase(SystemClock.elapsedRealtime());
                pauseTime=0;
                Running=false;

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(PREV_SUMMARY, workoutsummary.getText().toString());
                editor.apply();
                break;
        }
    }
    private void loadSharedPreference(){
        String text = sharedPreferences.getString(PREV_SUMMARY, "workout_summary");
        workoutsummary.setText(text);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        chronometer=(Chronometer)findViewById(R.id.chronometer);
        workoutsummary=findViewById(R.id.summary);
        workoutType=findViewById(R.id.workoutType);
        pauseTime=SystemClock.elapsedRealtime()-chronometer.getBase();

        sharedPreferences=getSharedPreferences("com.example.workouttimer",MODE_PRIVATE);
        loadSharedPreference();

        if(savedInstanceState!=null){
            workoutsummary.setText(savedInstanceState.getString(Summary));
            pauseTime=savedInstanceState.getLong(Pause);
            chronometer.setBase(SystemClock.elapsedRealtime()+savedInstanceState.getLong(Base));
            if(savedInstanceState.getBoolean(Timer_time)){
                chronometer.start();
                Running=true;

            }
            else {
                chronometer.setBase(SystemClock.elapsedRealtime()-pauseTime);
            }

        }
        else {
            Running=false;
        }

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(Summary,workoutsummary.getText().toString());
        outState.putLong(Base,chronometer.getBase()-SystemClock.elapsedRealtime());
        outState.putBoolean(Timer_time,Running);
        outState.putLong(Pause,pauseTime);
    }

}